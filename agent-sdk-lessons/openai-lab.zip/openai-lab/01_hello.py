import setup_model  # 무료 Gemini 키로 연습할 때만 동작합니다(자료실 참고)
from agents import Agent, Runner

agent = Agent(
    name="매출 도우미",
    instructions="너는 팝콘상사 직원을 돕는 도우미야. 한국어로 짧고 정확하게 답해.",
)

result = Runner.run_sync(agent, "매출 데이터를 분석할 때 가장 먼저 확인할 것 세 가지를 알려 줘.")
print(result.final_output)
