import setup_model  # 무료 Gemini 키로 연습할 때만 동작합니다(자료실 참고)
from agents import Agent, Runner, function_tool
from sales_data import revenue_by, monthly_target


@function_tool
def get_revenue(group_by: str, month: str = "") -> dict:
    """팝콘상사 매출 합계를 돌려줍니다.

    Args:
        group_by: branch(지점), product(상품), month(월) 중 하나.
        month: '2026-11'처럼 쓰면 그 달만 셉니다. 비우면 전체 기간.
    """
    return revenue_by(group_by, month)


@function_tool
def get_target(branch: str) -> dict:
    """지점의 2026년 11월 매출 목표(원)를 돌려줍니다.

    Args:
        branch: 강남점, 홍대점, 판교점 중 하나.
    """
    return monthly_target(branch)


agent = Agent(
    name="매출 도우미",
    instructions="숫자는 반드시 도구 결과만 써. 직접 계산이 필요하면 계산 과정을 보여 줘.",
    tools=[get_revenue, get_target],
)

result = Runner.run_sync(agent, "2026년 11월 강남점 매출이 목표를 넘었어?")
for item in result.new_items:                 # 에이전트가 거친 단계를 그대로 봅니다
    print("·", item.type)
print("\n[답]", result.final_output)
