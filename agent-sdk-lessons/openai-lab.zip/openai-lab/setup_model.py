"""연습용 모델 설정. OpenAI API 키가 있으면 아무것도 하지 않습니다.

OpenAI 키 없이 무료 Gemini API 키로 연습할 때:
    export GEMINI_API_KEY=...            # Google AI Studio에서 발급
    export OPENAI_DEFAULT_MODEL=gemini-flash-lite-latest   # 선택. 내 키로 쓸 수 있는 모델 이름
그러면 모든 에이전트가 Gemini의 OpenAI 호환 주소로 요청을 보냅니다.
"""
import os
from openai import AsyncOpenAI
from agents import set_default_openai_api, set_default_openai_client, set_tracing_disabled

GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"

if os.getenv("GEMINI_API_KEY") and not os.getenv("OPENAI_API_KEY"):
    base_url = os.getenv("PRACTICE_BASE_URL", GEMINI_BASE_URL)   # 로컬 모델(Ollama)로 바꿀 때만 씁니다
    os.environ.setdefault("OPENAI_DEFAULT_MODEL", "gemini-flash-lite-latest")
    client = AsyncOpenAI(base_url=base_url, api_key=os.environ["GEMINI_API_KEY"])
    set_default_openai_client(client, use_for_tracing=False)
    set_default_openai_api("chat_completions")   # Gemini는 Chat Completions 방식으로 부릅니다
    set_tracing_disabled(True)                   # 실행 기록은 OpenAI 키가 있어야 올라가므로 끕니다
    print(f"[연습 모드] {base_url} · 모델 {os.environ['OPENAI_DEFAULT_MODEL']}\n")
