"""미니 프로젝트: 매니저 에이전트가 분석가를 '도구처럼' 불러 11월 리포트를 만든다."""
import setup_model  # 무료 Gemini 키로 연습할 때만 동작합니다(자료실 참고)
from pathlib import Path
from pydantic import BaseModel
from agents import Agent, Runner, function_tool
from sales_data import revenue_by, monthly_target


@function_tool
def get_revenue(group_by: str, month: str = "") -> dict:
    """매출 합계. group_by는 branch/product/month, month는 '2026-11' 형식(비우면 전체)."""
    return revenue_by(group_by, month)


@function_tool
def get_target(branch: str) -> dict:
    """지점의 2026년 11월 매출 목표(원). branch는 강남점/홍대점/판교점."""
    return monthly_target(branch)


class BranchRow(BaseModel):
    branch: str
    revenue: int
    target: int


class MonthlyReport(BaseModel):
    month: str
    branches: list[BranchRow]
    best_product: str
    summary: str


analyst = Agent(
    name="매출 분석가",
    instructions="도구 결과 숫자만 그대로 전달해. 추정하지 마.",
    tools=[get_revenue, get_target],
)

manager = Agent(
    name="리포트 매니저",
    instructions=("2026-11 리포트를 만든다. 지점별 매출과 목표, 상품별 매출은 반드시 분석가에게 물어서 받는다. "
                  "분석가가 알려 주지 않은 숫자나 상품 이름은 쓰지 않는다."),
    tools=[analyst.as_tool(tool_name="ask_analyst", tool_description="매출·목표 숫자를 물어본다")],
    output_type=MonthlyReport,
)

result = Runner.run_sync(manager, "2026년 11월 매출 리포트를 만들어 줘.", max_turns=15)
report: MonthlyReport = result.final_output

lines = [f"# {report.month} 매출 리포트", "", "| 지점 | 매출 | 목표 | 달성률 |", "|---|---:|---:|---:|"]
lines += [f"| {b.branch} | {b.revenue:,} | {b.target:,} | {b.revenue / b.target * 100:.1f}% |"   # 달성률은 코드가 계산
          for b in report.branches if b.target]
lines += ["", f"- 가장 많이 팔린 상품: {report.best_product}", f"- 요약: {report.summary}"]
Path("report_2026-11.md").write_text("\n".join(lines), encoding="utf-8")
print("\n".join(lines))

# 검증: 에이전트가 쓴 숫자를 원본 계산과 대조합니다
truth = revenue_by("branch", "2026-11")
for b in report.branches:
    real = truth.get(b.branch)
    if real is None:
        print(f"검증 {b.branch}: 없는 지점 이름")
    else:
        print(f"검증 {b.branch}: " + ("OK" if real == b.revenue else f"다름(원본 {real:,})"))
best = next(iter(revenue_by("product", "2026-11")))   # 원본에서 11월 매출 1위 상품
print(f"검증 1위 상품: " + ("OK" if report.best_product == best else f"다름(원본 {best})"))
missing = sorted(set(truth) - {b.branch for b in report.branches})
if missing:
    print("검증: 리포트에 빠진 지점", missing)
