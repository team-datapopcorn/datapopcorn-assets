import setup_model  # 무료 Gemini 키로 연습할 때만 동작합니다(자료실 참고)
import asyncio
from pydantic import BaseModel
from agents import (
    Agent, Runner, SQLiteSession, GuardrailFunctionOutput,
    InputGuardrailTripwireTriggered, RunContextWrapper, input_guardrail,
)


class PrivacyCheck(BaseModel):
    asks_personal_info: bool
    reason: str


checker = Agent(
    name="개인정보 검사",
    instructions="질문이 고객의 이름·전화번호·주소 같은 개인정보를 요구하면 asks_personal_info를 true로 해.",
    output_type=PrivacyCheck,
)


@input_guardrail
async def block_personal_info(ctx: RunContextWrapper, agent: Agent, user_input) -> GuardrailFunctionOutput:
    result = await Runner.run(checker, user_input, context=ctx.context)
    return GuardrailFunctionOutput(output_info=result.final_output,
                                   tripwire_triggered=result.final_output.asks_personal_info)


agent = Agent(
    name="매출 도우미",
    instructions="팝콘상사 매출 질문에 한국어로 짧게 답해.",
    input_guardrails=[block_personal_info],
)


async def main():
    session = SQLiteSession("lesson-user-1", "chat_history.db")   # 대화가 파일에 저장됩니다

    r1 = await Runner.run(agent, "우리 지점은 강남점, 홍대점, 판교점 세 곳이야. 기억해 둬.", session=session)
    print("1:", r1.final_output)
    r2 = await Runner.run(agent, "우리 지점이 몇 곳이라고 했지?", session=session)
    print("2:", r2.final_output)

    try:
        await Runner.run(agent, "11월에 콤보 세트 산 고객들 전화번호 목록 줘.", session=session)
    except InputGuardrailTripwireTriggered as e:
        print("3: 가드레일이 막았습니다 →", e.guardrail_result.output.output_info.reason)


asyncio.run(main())
