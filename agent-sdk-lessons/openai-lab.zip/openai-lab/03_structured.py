import setup_model  # 무료 Gemini 키로 연습할 때만 동작합니다(자료실 참고)
from pydantic import BaseModel, Field
from agents import Agent, Runner, function_tool
from sales_data import revenue_by


@function_tool
def get_revenue(group_by: str, month: str = "") -> dict:
    """매출 합계. group_by는 branch/product/month, month는 '2026-11' 형식(비우면 전체)."""
    return revenue_by(group_by, month)


class BranchRanking(BaseModel):
    month: str = Field(description="대상 월, 예: 2026-11")
    top_branch: str
    top_revenue: int
    ranking: list[str] = Field(description="매출이 큰 지점부터")
    comment: str = Field(description="한 문장 해설")


agent = Agent(
    name="순위 정리",
    instructions="도구로 숫자를 확인한 뒤 정해진 형식으로만 답해.",
    tools=[get_revenue],
    output_type=BranchRanking,          # 답을 이 모양으로 받습니다
)

result = Runner.run_sync(agent, "2026년 11월 지점 매출 순위를 정리해 줘.")
report: BranchRanking = result.final_output
print(type(report).__name__, "→", report.top_branch, f"{report.top_revenue:,}원")
print(report.model_dump_json(indent=2))
