import setup_model  # 무료 Gemini 키로 연습할 때만 동작합니다(자료실 참고)
from agents import Agent, Runner, function_tool
from sales_data import revenue_by


@function_tool
def get_revenue(group_by: str, month: str = "") -> dict:
    """매출 합계. group_by는 branch/product/month, month는 '2026-11' 형식(비우면 전체)."""
    return revenue_by(group_by, month)


analyst = Agent(
    name="sales_analyst",   # 영어로: 넘기기 도구 이름(transfer_to_...)이 됩니다
    handoff_description="매출, 지점, 상품 숫자에 관한 질문",
    instructions="도구로 숫자를 확인하고 답해.",
    tools=[get_revenue],
)

cs_agent = Agent(
    name="customer_support",
    handoff_description="환불, 교환, 매장 이용 같은 고객 문의",
    instructions="환불 규정: 구매 후 7일 이내, 개봉 전 상품만 환불. 규정에 없는 내용은 매장에 문의하라고 안내해.",
)

triage = Agent(
    name="triage",
    instructions="질문을 읽고 알맞은 담당에게 넘겨. 직접 답하지 마.",
    handoffs=[analyst, cs_agent],
)

for question in ["지난 3개월 동안 가장 많이 팔린 상품은?", "어제 산 팝콘을 뜯었는데 환불되나요?"]:
    result = Runner.run_sync(triage, question)
    print(f"Q: {question}\n→ 답한 에이전트: {result.last_agent.name}\nA: {result.final_output}\n")
