import { ToolLoopAgent, Output } from 'ai';
import { google } from '@ai-sdk/google';
import { z } from 'zod';
import { getRevenue } from './tools.ts';

const BranchRanking = z.object({
  month: z.string().describe('대상 월, 예: 2026-11'),
  topBranch: z.string(),
  topRevenue: z.number().int(),
  ranking: z.array(z.string()).describe('매출이 큰 지점부터'),
  comment: z.string().describe('한 문장 해설'),
});

const agent = new ToolLoopAgent({
  model: google('gemini-flash-lite-latest'),
  instructions: '도구로 숫자를 확인한 뒤 정해진 형식으로만 답해.',
  tools: { getRevenue },
  output: Output.object({ schema: BranchRanking }), // 답을 이 모양으로 받습니다
});

const { output } = await agent.generate({ prompt: '2026년 11월 지점 매출 순위를 정리해 줘.' });
console.log(output.topBranch, `${output.topRevenue.toLocaleString()}원`);
console.log(JSON.stringify(output, null, 2));
