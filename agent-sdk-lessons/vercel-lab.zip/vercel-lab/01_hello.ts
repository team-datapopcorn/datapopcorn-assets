import { generateText } from 'ai';
import { google } from '@ai-sdk/google';

const { text, usage } = await generateText({
  model: google('gemini-flash-lite-latest'),
  system: '너는 팝콘상사 직원을 돕는 도우미야. 한국어로 짧고 정확하게 답해.',
  prompt: '매출 데이터를 분석할 때 가장 먼저 확인할 것 세 가지를 알려 줘.',
});

console.log(text);
console.log('\n토큰 사용량(입력+출력):', usage.totalTokens);
