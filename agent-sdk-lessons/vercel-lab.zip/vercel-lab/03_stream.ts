import { ToolLoopAgent } from 'ai';
import { google } from '@ai-sdk/google';
import { getRevenue } from './tools.ts';

const agent = new ToolLoopAgent({
  model: google('gemini-flash-lite-latest'),
  instructions: '도구로 숫자를 확인한 뒤 한국어로 설명해.',
  tools: { getRevenue },
});

const result = await agent.stream({ prompt: '9월부터 11월까지 월별 매출 흐름을 설명해 줘.' });

for await (const part of result.fullStream) {
  if (part.type === 'tool-call') console.log(`\n[도구 호출] ${part.toolName} ${JSON.stringify(part.input)}`);
  if (part.type === 'tool-result') console.log(`[도구 결과] ${JSON.stringify(part.output)}\n`);
  if (part.type === 'text-delta') process.stdout.write(part.text); // 글자가 생기는 대로 바로 출력
}
console.log('\n\n[끝] 단계 수:', (await result.steps).length);
