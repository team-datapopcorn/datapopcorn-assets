// 팝콘상사 매출 데이터 도우미 함수. 에이전트의 '도구'는 결국 이런 평범한 함수입니다.
import { readFileSync } from 'node:fs';

type Row = { date: string; branch: string; product: string; qty: number; revenue: number };

// 회사 내부 시스템에만 있는 값이라고 가정합니다(모델은 모르는 정보).
export const TARGETS_2026_11: Record<string, number> = { 강남점: 5_500_000, 홍대점: 5_500_000, 판교점: 4_500_000 };

export function loadRows(): Row[] {
  const [, ...lines] = readFileSync(new URL('./sales.csv', import.meta.url), 'utf-8').trim().split('\n');
  return lines.map((line) => {
    const [date, branch, product, qty, revenue] = line.split(',');
    return { date, branch, product, qty: Number(qty), revenue: Number(revenue) };
  });
}

export function revenueBy(groupBy: 'branch' | 'product' | 'month', month = ''): Record<string, number> {
  const total: Record<string, number> = {};
  for (const row of loadRows()) {
    if (month && !row.date.startsWith(month)) continue;
    const key = groupBy === 'month' ? row.date.slice(0, 7) : row[groupBy];
    total[key] = (total[key] ?? 0) + row.revenue;
  }
  return Object.fromEntries(Object.entries(total).sort((a, b) => b[1] - a[1]));
}

export function monthlyTarget(branch: string) {
  if (!(branch in TARGETS_2026_11)) return { error: `${branch}은(는) 없는 지점입니다` };
  return { branch, month: '2026-11', target: TARGETS_2026_11[branch] };
}
