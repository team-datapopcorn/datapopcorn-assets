import { ToolLoopAgent, isStepCount } from 'ai';
import { google } from '@ai-sdk/google';
import { getRevenue, getTarget } from './tools.ts';

const agent = new ToolLoopAgent({
  model: google('gemini-flash-lite-latest'),
  instructions: '숫자는 반드시 도구 결과만 써. 직접 계산이 필요하면 계산 과정을 보여 줘.',
  tools: { getRevenue, getTarget },
  stopWhen: isStepCount(8), // 최대 8단계까지만 돕니다(기본값 20)
});

const result = await agent.generate({ prompt: '2026년 11월 강남점 매출이 목표를 넘었어?' });

for (const [i, step] of result.steps.entries()) {
  for (const call of step.toolCalls) console.log(`단계 ${i + 1}: ${call.toolName}`, JSON.stringify(call.input));
}
console.log('\n[답]', result.text);
