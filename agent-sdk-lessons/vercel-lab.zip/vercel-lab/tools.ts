import { tool } from 'ai';
import { z } from 'zod';
import { revenueBy, monthlyTarget } from './salesData.ts';

export const getRevenue = tool({
  description: '팝콘상사 매출 합계를 돌려준다',
  inputSchema: z.object({
    groupBy: z.enum(['branch', 'product', 'month']).describe('branch=지점, product=상품, month=월'),
    month: z.string().optional().describe("'2026-11'처럼 쓰면 그 달만. 비우면 전체 기간"),
  }),
  execute: async ({ groupBy, month }) => revenueBy(groupBy, month ?? ''),
});

export const getTarget = tool({
  description: '지점의 2026년 11월 매출 목표(원)',
  inputSchema: z.object({ branch: z.enum(['강남점', '홍대점', '판교점']) }),
  execute: async ({ branch }) => monthlyTarget(branch),
});
