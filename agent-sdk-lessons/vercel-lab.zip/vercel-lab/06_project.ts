// 미니 프로젝트: 11월 매출 리포트 에이전트 (도구 + 구조화 출력 + 파일 저장 + 검증)
import { writeFileSync } from 'node:fs';
import { ToolLoopAgent, Output, isStepCount } from 'ai';
import { google } from '@ai-sdk/google';
import { z } from 'zod';
import { getRevenue, getTarget } from './tools.ts';
import { revenueBy } from './salesData.ts';

const MonthlyReport = z.object({
  month: z.string(),
  branches: z.array(z.object({
    branch: z.string(), revenue: z.number().int(), target: z.number().int(),
  })),
  bestProduct: z.string(),
  summary: z.string(),
});

const agent = new ToolLoopAgent({
  model: google('gemini-flash-lite-latest'),
  instructions:
    '너는 팝콘상사 매출 리포트 담당이야. 숫자와 상품 이름은 도구 결과만 쓰고 추정하지 않는다.',
  tools: { getRevenue, getTarget },
  output: Output.object({ schema: MonthlyReport }),
  stopWhen: isStepCount(12),
});

const { output: report, steps } = await agent.generate({ prompt: '2026년 11월 매출 리포트를 만들어 줘.' });

const lines = [
  `# ${report.month} 매출 리포트`, '', '| 지점 | 매출 | 목표 | 달성률 |', '|---|---:|---:|---:|',
  ...report.branches.map((b) => // 달성률은 코드가 계산합니다
    `| ${b.branch} | ${b.revenue.toLocaleString()} | ${b.target.toLocaleString()} | ${b.target ? ((b.revenue / b.target) * 100).toFixed(1) + '%' : '-'} |`),
  '', `- 가장 많이 팔린 상품: ${report.bestProduct}`, `- 요약: ${report.summary}`,
];
writeFileSync('report_2026-11.md', lines.join('\n'));
console.log(lines.join('\n'), `\n\n(단계 ${steps.length}개)`);

// 검증: 에이전트가 쓴 숫자를 원본 계산과 대조합니다
const truth = revenueBy('branch', '2026-11');
for (const b of report.branches) {
  const real = truth[b.branch];
  if (real === undefined) console.log(`검증 ${b.branch}: 없는 지점 이름`);
  else console.log(`검증 ${b.branch}:`, real === b.revenue ? 'OK' : `다름(원본 ${real.toLocaleString()})`);
}
const best = Object.keys(revenueBy('product', '2026-11'))[0]; // 원본에서 11월 매출 1위 상품
console.log('검증 1위 상품:', report.bestProduct === best ? 'OK' : `다름(원본 ${best})`);
const missing = Object.keys(truth).filter((k) => !report.branches.some((b) => b.branch === k));
if (missing.length) console.log('검증: 리포트에 빠진 지점', missing);
