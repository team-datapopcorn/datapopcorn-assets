import { ToolLoopAgent, tool, hasToolCall, isStepCount } from 'ai';
import { google } from '@ai-sdk/google';
import { z } from 'zod';
import { getRevenue, getTarget } from './tools.ts';

// 최종 보고용 도구: 실행 함수가 없어서, 모델이 이걸 부르는 순간 루프가 끝납니다.
const finalAnswer = tool({
  description: '조사를 마쳤을 때 최종 결론을 제출한다',
  inputSchema: z.object({ verdict: z.string(), evidence: z.array(z.string()) }),
});

const agent = new ToolLoopAgent({
  model: google('gemini-flash-lite-latest'),
  instructions: '세 지점의 11월 목표 달성 여부를 조사하고 finalAnswer로 제출해.',
  tools: { getRevenue, getTarget, finalAnswer },
  stopWhen: [hasToolCall('finalAnswer'), isStepCount(10)], // 둘 중 먼저 오는 조건에서 멈춤
  prepareStep: async ({ stepNumber }) => {
    // 첫 단계에서는 매출 조회 도구만 보이게 해서 매출부터 확인하게 합니다
    if (stepNumber === 0) return { activeTools: ['getRevenue'] };
    return {};
  },
  onStepFinish: ({ toolCalls, usage }) => {
    console.log('단계 끝 →', toolCalls.map((c) => c.toolName).join(', ') || '(글만 씀)', '| 토큰', usage.totalTokens);
  },
});

const result = await agent.generate({ prompt: '11월 목표를 달성한 지점은 어디야?' });
const last = result.steps.at(-1)?.toolCalls.find((c) => c.toolName === 'finalAnswer');
if (last) console.log('\n[결론]', JSON.stringify(last.input, null, 2));
else console.log('\n[결론 없음] finalAnswer를 부르지 않고 끝났습니다. 마지막 글:', result.text);
