"""팝콘상사 매출 데이터 도우미 함수. 에이전트의 '도구'는 결국 이런 평범한 함수입니다."""
import csv
from collections import Counter
from pathlib import Path

CSV_PATH = Path(__file__).with_name("sales.csv")

# 회사 내부 시스템에만 있는 값이라고 가정합니다(모델은 모르는 정보).
TARGETS_2026_11 = {"강남점": 5_500_000, "홍대점": 5_500_000, "판교점": 4_500_000}


def load_rows():
    with open(CSV_PATH, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def revenue_by(group_by: str, month: str = "") -> dict:
    """group_by: branch(지점) | product(상품) | month(월). month: '2026-11'처럼 쓰면 그 달만 셉니다."""
    if group_by not in ("branch", "product", "month"):
        return {"error": "group_by는 branch, product, month 중 하나여야 합니다"}
    total = Counter()
    for row in load_rows():
        if month and not row["date"].startswith(month):
            continue
        key = row["date"][:7] if group_by == "month" else row[group_by]
        total[key] += int(row["revenue"])
    return dict(total.most_common())


def monthly_target(branch: str) -> dict:
    """2026년 11월 지점별 매출 목표(원)."""
    if branch not in TARGETS_2026_11:
        return {"error": f"{branch}은(는) 없는 지점입니다. 지점: {list(TARGETS_2026_11)}"}
    return {"branch": branch, "month": "2026-11", "target": TARGETS_2026_11[branch]}
