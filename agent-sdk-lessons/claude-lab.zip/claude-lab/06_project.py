"""미니 프로젝트: 11월 매출 리포트 에이전트 (내 도구 + 파일 저장 + 안전장치)"""
import asyncio
from pathlib import Path
from typing import Any
from claude_agent_sdk import (
    tool, create_sdk_mcp_server, query, ClaudeAgentOptions,
    AssistantMessage, ResultMessage, ToolUseBlock,
)
from sales_data import revenue_by, monthly_target


@tool("revenue_by", "매출 합계. group_by=branch/product/month, month='2026-11' 형식(비우면 전체)",
      {"group_by": str, "month": str})
async def revenue_by_tool(args: dict[str, Any]) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": str(revenue_by(args["group_by"], args.get("month", "")))}]}


@tool("monthly_target", "지점의 2026년 11월 매출 목표(원)", {"branch": str})
async def monthly_target_tool(args: dict[str, Any]) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": str(monthly_target(args["branch"]))}]}


SYSTEM = """너는 팝콘상사 매출 리포트 담당이야.
- 숫자는 반드시 도구 결과만 쓴다. 직접 더하거나 추정하지 않는다.
- 리포트는 report_2026-11.md 파일 하나로 저장한다.
- 리포트 구성: 지점별 11월 매출, 목표, 달성률(%) 표 / 상품별 11월 매출 / 한 줄 요약."""


async def main():
    server = create_sdk_mcp_server(name="sales", version="1.0.0",
                                   tools=[revenue_by_tool, monthly_target_tool])
    options = ClaudeAgentOptions(
        system_prompt=SYSTEM,
        tools=["Write"],
        mcp_servers={"sales": server},
        allowed_tools=["mcp__sales__revenue_by", "mcp__sales__monthly_target", "Write"],
        permission_mode="acceptEdits",
        max_turns=15,
        max_budget_usd=1.00,
    )
    async for message in query(prompt="2026년 11월 매출 리포트를 만들어 줘.", options=options):
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, ToolUseBlock):
                    print("[도구]", block.name, str(block.input)[:80])
        elif isinstance(message, ResultMessage):
            print("[끝]", message.subtype, "| 비용(USD):", message.total_cost_usd)

    report = Path("report_2026-11.md")
    print("\n--- 저장된 리포트 ---\n" + (report.read_text(encoding="utf-8") if report.exists() else "(파일 없음)"))


asyncio.run(main())
