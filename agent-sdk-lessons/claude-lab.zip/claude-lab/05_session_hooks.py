import asyncio
from claude_agent_sdk import (
    ClaudeSDKClient, ClaudeAgentOptions, HookMatcher,
    AssistantMessage, ResultMessage, TextBlock,
)


async def log_tool(input_data, tool_use_id, context):
    """도구를 쓰기 직전에 기록만 남기는 훅. 막을 수도 있습니다(4장 참고)."""
    print(f"  [기록] {input_data['tool_name']} 사용")
    return {}


async def ask(client, text):
    print(f"\n나: {text}")
    await client.query(text)
    async for message in client.receive_response():
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    print("Claude:", block.text)
        elif isinstance(message, ResultMessage):
            print(f"  (세션 {message.session_id[:8]}…, 누적 비용 {message.total_cost_usd})")


async def main():
    options = ClaudeAgentOptions(
        tools=["Read", "Glob"],
        allowed_tools=["Read", "Glob"],
        hooks={"PreToolUse": [HookMatcher(matcher="Read|Glob", hooks=[log_tool])]},
        max_turns=6,
        max_budget_usd=0.50,   # 이 금액을 넘으면 멈춥니다
    )
    async with ClaudeSDKClient(options=options) as client:
        await ask(client, "sales.csv를 읽어 두기만 해. 몇 줄인지만 말해 줘.")
        await ask(client, "방금 읽은 파일에서 지점 이름이 몇 개였지?")   # 앞 대화를 기억합니다


asyncio.run(main())
