import asyncio
from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, ResultMessage, TextBlock, ToolUseBlock

PROMPT = """sales.csv에서 지점(branch)별 매출(revenue) 합계를 python3로 계산해.
계산 결과를 표로 만들어 summary.md 파일에 저장하고, 저장한 내용을 짧게 알려 줘."""


async def main():
    options = ClaudeAgentOptions(
        tools=["Read", "Write", "Bash", "Glob"],
        allowed_tools=["Read", "Glob", "Bash(python3 *)"],  # python3로 시작하는 명령만 미리 허락
        permission_mode="acceptEdits",                       # 파일 만들기·고치기는 자동 승인
        max_turns=10,
    )
    async for message in query(prompt=PROMPT, options=options):
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    print("[답]", block.text)
                elif isinstance(block, ToolUseBlock):
                    print("[도구]", block.name, str(block.input)[:120])
        elif isinstance(message, ResultMessage):
            print("[끝]", message.subtype)


asyncio.run(main())
