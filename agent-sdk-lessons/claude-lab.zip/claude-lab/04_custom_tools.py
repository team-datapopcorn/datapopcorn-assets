import asyncio
from typing import Any
from claude_agent_sdk import (
    tool, create_sdk_mcp_server, query, ClaudeAgentOptions,
    AssistantMessage, ResultMessage, TextBlock, ToolUseBlock,
)
from sales_data import revenue_by, monthly_target


@tool("revenue_by", "팝콘상사 매출 합계. group_by는 branch/product/month, month는 '2026-11' 형식(비우면 전체)",
      {"group_by": str, "month": str})
async def revenue_by_tool(args: dict[str, Any]) -> dict[str, Any]:
    result = revenue_by(args["group_by"], args.get("month", ""))
    return {"content": [{"type": "text", "text": str(result)}]}


@tool("monthly_target", "지점의 2026년 11월 매출 목표(원)", {"branch": str})
async def monthly_target_tool(args: dict[str, Any]) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": str(monthly_target(args["branch"]))}]}


sales_server = create_sdk_mcp_server(name="sales", version="1.0.0",
                                     tools=[revenue_by_tool, monthly_target_tool])


async def main():
    options = ClaudeAgentOptions(
        tools=[],                                  # 내장 도구는 끄고
        mcp_servers={"sales": sales_server},       # 내가 만든 도구만 붙입니다
        allowed_tools=["mcp__sales__revenue_by", "mcp__sales__monthly_target"],
        max_turns=8,
    )
    prompt = "2026년 11월 강남점 매출이 목표를 넘었는지 숫자로 알려 줘."
    async for message in query(prompt=prompt, options=options):
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, ToolUseBlock):
                    print("[도구]", block.name, block.input)
                elif isinstance(block, TextBlock):
                    print("[답]", block.text)
        elif isinstance(message, ResultMessage):
            print("[끝]", message.subtype)


asyncio.run(main())
