import asyncio
from pathlib import Path
from claude_agent_sdk import (
    query, ClaudeAgentOptions, ResultMessage,
    PermissionResultAllow, PermissionResultDeny, ToolPermissionContext,
)

OUT_DIR = Path("out").resolve()
OUT_DIR.mkdir(exist_ok=True)
PROMPT = ("sales.csv를 읽고 상품별 매출 순위를 report.md로 저장해 줘. "
          "먼저 현재 폴더에 저장해 보고, 막히면 out 폴더에 저장해.")


async def guard(tool_name: str, tool_input: dict, context: ToolPermissionContext):
    """도구를 쓰기 직전마다 불립니다. 허락할지 막을지 내가 코드로 정합니다."""
    if tool_name == "Write":
        target = Path(tool_input.get("file_path", "")).resolve()
        if OUT_DIR not in target.parents:
            print(f"  ✋ 막음: out 폴더 밖에 쓰려고 함 → {target}")
            return PermissionResultDeny(message="파일은 out 폴더 안에만 저장할 수 있습니다.")
    if tool_name == "Bash" and "rm " in tool_input.get("command", ""):
        print("  ✋ 막음: 삭제 명령")
        return PermissionResultDeny(message="삭제 명령은 쓸 수 없습니다.")
    print(f"  ✅ 허락: {tool_name}")
    return PermissionResultAllow()


async def main():
    options = ClaudeAgentOptions(
        tools=["Read", "Write", "Bash", "Glob"],
        can_use_tool=guard,
        max_turns=10,
    )
    async for message in query(prompt=PROMPT, options=options):
        if isinstance(message, ResultMessage):
            print("[끝]", message.subtype)
            print("[결과]", message.result)


asyncio.run(main())
