import asyncio
from claude_agent_sdk import query, ClaudeAgentOptions, AssistantMessage, ResultMessage, TextBlock, ToolUseBlock


async def main():
    options = ClaudeAgentOptions(
        tools=["Read", "Glob"],          # 이 두 도구만 쓸 수 있게 합니다
        allowed_tools=["Read", "Glob"],  # 묻지 않고 바로 쓰게 미리 허락합니다
        max_turns=5,
    )
    prompt = "sales.csv의 처음 다섯 줄을 읽고, 어떤 열이 있는지 한국어로 설명해 줘."
    async for message in query(prompt=prompt, options=options):
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    print("[답]", block.text)
                elif isinstance(block, ToolUseBlock):
                    print("[도구]", block.name, block.input)
        elif isinstance(message, ResultMessage):
            print("[끝]", message.subtype, "| 턴:", message.num_turns, "| 비용(USD):", message.total_cost_usd)


asyncio.run(main())
